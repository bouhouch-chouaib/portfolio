#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define VMIN 5
#define VMAX 30

// Structure pour représenter une case
typedef struct {
    int ligne;
    int colonne;
} T_Case;

// Prototype des fonctions
int Lire_Entier(int min, int max);
void Parametres(int *nlig, int *ncol, int *niveau, int *next);
void Afficher_Grille(int nlig, int ncol, T_Case pion);
void Voisines(T_Case pion, T_Case vois[], int *nb_vois, int nlig, int ncol);
T_Case Coup_Joueur(T_Case pion, int nlig, int ncol);
T_Case Coup_Ordi_Hasard(T_Case pion, int nlig, int ncol);
int Nimber(int i, int j, int nlig, int ncol);
T_Case Coup_Ordi_Gagnant(T_Case pion, int nlig, int ncol, int niveau);

int main() {
    int nlig, ncol, niveau, next;
    T_Case pion = {1, 1}; // Position initiale du pion
    srand(time(NULL));    // Initialisation du générateur de nombres aléatoires

    // Saisie des paramètres du jeu
    Parametres(&nlig, &ncol, &niveau, &next);

    printf("C'est parti !\n");
    while (!(pion.ligne == nlig && pion.colonne == ncol)) { // Tant que le pion n'est pas dans le puits
        Afficher_Grille(nlig, ncol, pion);

        if (next == 2) { // Tour du joueur
            printf("À toi de jouer !\n");
            pion = Coup_Joueur(pion, nlig, ncol);
            next = 1; // Passe au tour de l'ordinateur
        } else { // Tour de l'ordinateur
            printf("Tour de l'ordinateur...\n");
            if (niveau == 1) {
                pion = Coup_Ordi_Hasard(pion, nlig, ncol);
            } else {
                pion = Coup_Ordi_Gagnant(pion, nlig, ncol, niveau);
            }
            printf("L'ordinateur a déplacé le pion en (%d, %d)\n", pion.ligne, pion.colonne);
            next = 2; // Passe au tour du joueur
        }
    }

    // Déterminer le gagnant
    printf("C'est terminé. %s a gagné !\n", (next == 2) ? "L'ordinateur" : "Vous");
    return 0;
}

// Fonction pour lire un entier dans une plage donnée
int Lire_Entier(int min, int max) {
    int val;
    do {
        printf("Entrez un entier entre %d et %d : ", min, max);
        scanf("%d", &val);
    } while (val < min || val > max);
    return val;
}

// Fonction pour saisir les paramètres du jeu
void Parametres(int *nlig, int *ncol, int *niveau, int *next) {
    printf("Paramètres du jeu :\n");
    printf("Nombre de lignes : ");
    *nlig = Lire_Entier(VMIN, VMAX);
    printf("Nombre de colonnes : ");
    *ncol = Lire_Entier(VMIN, VMAX);
    printf("Niveau de difficulté (1 = débutant, 2 = moyen, 3 = expert, 4 = virtuose) : ");
    *niveau = Lire_Entier(1, 4);
    printf("Qui commence ? 1 (Ordinateur) ou 2 (Joueur) : ");
    *next = Lire_Entier(1, 2);
}

// Fonction pour afficher la grille
void Afficher_Grille(int nlig, int ncol, T_Case pion) {
    for (int i = 1; i <= nlig; i++) {
        for (int j = 1; j <= ncol; j++) {
            if (i == pion.ligne && j == pion.colonne) {
                printf("O ");
            } else {
                printf("- ");
            }
        }
        printf("\n");
    }
    printf("\n");
}

// Fonction pour calculer les voisines d'une case
void Voisines(T_Case pion, T_Case vois[], int *nb_vois, int nlig, int ncol) {
    *nb_vois = 0;
    if (pion.colonne + 1 <= ncol) { // Droite
        vois[(*nb_vois)++] = (T_Case){pion.ligne, pion.colonne + 1};
    }
    if (pion.colonne + 2 <= ncol) { // Deux cases à droite
        vois[(*nb_vois)++] = (T_Case){pion.ligne, pion.colonne + 2};
    }
    if (pion.ligne + 1 <= nlig) { // Bas
        vois[(*nb_vois)++] = (T_Case){pion.ligne + 1, pion.colonne};
    }
    if (pion.ligne + 2 <= nlig) { // Deux cases en bas
        vois[(*nb_vois)++] = (T_Case){pion.ligne + 2, pion.colonne};
    }
}

// Fonction pour gérer le coup du joueur
T_Case Coup_Joueur(T_Case pion, int nlig, int ncol) {
    T_Case vois[4];
    int nb_vois, choix;
    Voisines(pion, vois, &nb_vois, nlig, ncol);

    for (int i = 0; i < nb_vois; i++) {
        printf("%d: (%d, %d) ", i + 1, vois[i].ligne, vois[i].colonne);
    }
    printf("\n");

    do {
        printf("Choisissez votre coup : ");
        scanf("%d", &choix);
    } while (choix < 1 || choix > nb_vois);

    return vois[choix - 1];
}

// Fonction pour un coup aléatoire de l'ordinateur
T_Case Coup_Ordi_Hasard(T_Case pion, int nlig, int ncol) {
    T_Case vois[4];
    int nb_vois;
    Voisines(pion, vois, &nb_vois, nlig, ncol);
    return vois[rand() % nb_vois];
}

// Fonction pour un coup gagnant de l'ordinateur
T_Case Coup_Ordi_Gagnant(T_Case pion, int nlig, int ncol, int niveau) {
    T_Case vois[4];
    int nb_vois, prob = rand() % 3;
    Voisines(pion, vois, &nb_vois, nlig, ncol);

    for (int i = 0; i < nb_vois; i++) {
        if (Nimber(vois[i].ligne, vois[i].colonne, nlig, ncol) == 0) {
            if (niveau == 4 || (niveau == 3 && prob >= 1) || (niveau == 2 && prob == 2)) {
                return vois[i];
            }
        }
    }

    return vois[rand() % nb_vois];
}

// Fonction pour calculer le nimber
int Nimber(int i, int j, int nlig, int ncol) {
    return (nlig - i) ^ (ncol - j); // XOR simplifié pour le jeu de Nim
}