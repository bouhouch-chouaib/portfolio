#include <stdio.h>
#include <stdlib.h>

#define MAX_DIM 10 // limite la taille du tableau à 10

// Codes ANSI pour les couleurs
#define COLOR_RESET "\033[0m"
#define COLOR_BLUE "\033[34m"
#define COLOR_RED "\033[31m"

void afficher_matrice(int matrice[MAX_DIM][MAX_DIM], int nb_ligne, int nb_colonne) {
    for (int i = 0; i < nb_ligne; i++) {
        printf("|");
        for (int j = 0; j < nb_colonne; j++) {
            if (matrice[i][j] == 0) {
                printf("  |");
            } else if (matrice[i][j] > 0) {
                printf(COLOR_BLUE "%2d" COLOR_RESET "|", matrice[i][j]);
            } else {
                printf(COLOR_RED "%2d" COLOR_RESET "|", -matrice[i][j]);
            }
            if (j < nb_colonne - 1) printf(" ");
        }
        printf("\n");
        if (i < nb_ligne - 1) {
            for (int j = 0; j < nb_colonne; j++) {
                printf("----"); // Trace une ligne de tiret sous chaque ligne
            }
            printf("\n");
        }
    }
    printf("\n");
} // affichage de la matrice

int main() {
    int nb_ligne, nb_colonne, matrice[MAX_DIM][MAX_DIM] = {0};
    int x, y, jeton, cases_vides;
    int rejouer;

    do {
        // Réinitialisation des variables pour une nouvelle partie
        jeton = 1;
        for (int i = 0; i < MAX_DIM; i++) {
            for (int j = 0; j < MAX_DIM; j++) {
                matrice[i][j] = 0;
            }
        }
        
        // Demande le nombre de lignes + vérification que le nombre donné soit pair sinon affichage d'un message d'erreur
         do {
        printf("Entrez le nombre de colonnes (entre 3 et 9) : ");
        scanf("%d", &nb_colonne);
        if (nb_colonne < 3 || nb_colonne > 10 || nb_colonne%2==0) {
            printf("Le nombre doit être compris entre 3 et 9, et doit être impair. Réessayez.\n");
        }
        } while (nb_colonne < 3 || nb_colonne > 10 || nb_colonne%2==0);

    
        do {
        printf("Entrez le nombre de lignes (entre 3 et 9) : ");
        scanf("%d", &nb_ligne);
        if (nb_ligne < 3 || nb_ligne > 10 || nb_ligne%2==0) {
            printf("Le nombre doit être compris entre 3 et 9, et doit être impair. Réessayez.\n");
        }
        } while (nb_ligne < 3 || nb_ligne > 10 || nb_ligne%2==0);
    
    printf("Vous avez choisi %d colonnes et %d lignes.\n\n", nb_colonne, nb_ligne);

        // Affichage de la matrice vide au début
        printf("Voici la matrice vide :\n");
        afficher_matrice(matrice, nb_ligne, nb_colonne);

        cases_vides = nb_ligne * nb_colonne;

        // Tour des joueurs
        while (cases_vides > 1) {
            // Joueur 1
            do {
                printf(COLOR_BLUE "Joueur 1, entrez les coordonnées pour le jeton %d (ligne colonne) : " COLOR_RESET, jeton);
                scanf("%d %d", &x, &y);
                x--; y--; // Ajustement pour l'indexation à partir de 0
             if (x < 0 || x >= nb_ligne || y < 0 || y >= nb_colonne || matrice[x][y] != 0) {
                printf("Coordonnées invalides ou case déjà occupée. Réessayez.\n");
            }
            } while (x < 0 || x >= nb_ligne || y < 0 || y >= nb_colonne || matrice[x][y] != 0);
            matrice[x][y] = jeton;
            cases_vides--;
           
            printf("Matrice après le coup du Joueur 1 :\n");
            afficher_matrice(matrice, nb_ligne, nb_colonne); // affichage de la matrice lorsque le joueur 1 a posé son jeton
           
            if (cases_vides == 1) break;

            // Joueur 2
            do {
                printf(COLOR_RED "Joueur 2, entrez les coordonnées pour le jeton %d (ligne colonne) : " COLOR_RESET, jeton);
                scanf("%d %d", &x, &y);
                x--; y--; // Ajustement pour l'indexation à partir de 0
            if (x < 0 || x >= nb_ligne || y < 0 || y >= nb_colonne || matrice[x][y] != 0) {
                printf("Coordonnées invalides ou case déjà occupée. Réessayez.\n");
            }
            } while (x < 0 || x >= nb_ligne || y < 0 || y >= nb_colonne || matrice[x][y] != 0);
            matrice[x][y] = -jeton;
            cases_vides--;
           
            printf("Matrice après le coup du Joueur 2 :\n");
            afficher_matrice(matrice, nb_ligne, nb_colonne); // affichage de la matrice lorsque le joueur 2 a posé son jeton

            jeton++; // on passe au jeton suivant
        }

        printf("Partie terminée. Il ne reste qu'une seule case vide. Voici la matrice finale :\n");
        afficher_matrice(matrice, nb_ligne, nb_colonne);

        // Détermination du gagnant
        int somme_joueur1 = 0, somme_joueur2 = 0;
        int case_vide_x, case_vide_y;

        // Trouver la case vide
        for (int i = 0; i < nb_ligne; i++) {
            for (int j = 0; j < nb_colonne; j++) {
                if (matrice[i][j] == 0) {
                    case_vide_x = i;
                    case_vide_y = j;
                    break;
                }
            }
            if (matrice[case_vide_x][case_vide_y] == 0) break;
        }

        // Calculer la somme des valeurs absolues autour de la case vide
        for (int i = case_vide_x - 1; i <= case_vide_x + 1; i++) {
            for (int j = case_vide_y - 1; j <= case_vide_y + 1; j++) {
                if (i >= 0 && i < nb_ligne && j >= 0 && j < nb_colonne && (i != case_vide_x || j != case_vide_y)) {
                    if (matrice[i][j] > 0) {
                        somme_joueur1 += matrice[i][j]; // somme des jetons du joueur 1
                    } else {
                        somme_joueur2 += abs(matrice[i][j]); // somme des jetons du joueur 2
                    }
                }
            }
        }

        // Annoncer le gagnant
        printf("\nSomme des jetons autour de la case vide :\n");
        printf(COLOR_BLUE "Joueur 1 : %d\n" COLOR_RESET, somme_joueur1);
        printf(COLOR_RED "Joueur 2 : %d\n" COLOR_RESET, somme_joueur2);

        if (somme_joueur1 < somme_joueur2) {
            printf(COLOR_BLUE "Le Joueur 1 gagne !\n" COLOR_RESET);
        } else if (somme_joueur2 < somme_joueur1) {
            printf(COLOR_RED "Le Joueur 2 gagne !\n" COLOR_RESET);
        } else {
            printf("C'est un match nul !\n");
        }
       
        printf("Voulez-vous jouer une nouvelle partie ? (1 pour oui, 0 pour non) : ");
        scanf("%d", &rejouer);

    } while (rejouer == 1);

    printf("Merci d'avoir joué !\n");
    return 0;
} 